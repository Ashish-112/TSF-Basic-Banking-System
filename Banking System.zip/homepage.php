<!DOCTYPE html>
<html>
<head>

<!---- The page has a title Lifestyle Store-->

<title>Banking system</title>


<!---- External css file index.css placed in the folder css is linked-->

<link  href="home.css" rel="stylesheet" type="text/css"/>
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" >
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
        <meta name="viewport" content="width=device-width, initial-scale=1">
</head>
<body>
      <div class="content">
          <div class="banner-image">
           <div class="inner-banner-image">
              <center>
               <div class="banner_content">
                   <p font-size="40px";>A SMART WAY TO BANK!!!
                       <br>Save and Invest. Make it Happen.</p>
                    <center>
<a href="views.php" class="button">VIEW CUSTOMERS</a>
                    </center>
                        
                </div>
              </center>
           </div>
        </div>
          </div>
    
       <footer class="footer">
            Ashish © TSF Online Banking 2021
        </footer>
    </body>
</html>